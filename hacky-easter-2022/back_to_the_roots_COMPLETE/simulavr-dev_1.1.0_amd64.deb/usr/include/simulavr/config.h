/* just a dummy file */
#define VERSION "1.1.0"
/* EOF */
